-- Profile
INSERT INTO profile (name, email, education, github, linkedin, achievement)
VALUES (
  'Paranji Punith Kumar',
  'punith587.t@gmail.com',
  'B.Tech Computer Science and Engineering (Cyber Security), IIIT Kottayam (2022–2026), CGPA: 7.38/10',
  'https://github.com/punith587', -- update if you have actual GitHub
  'https://www.linkedin.com/in/paranji-punith-kumar', -- update if you have actual LinkedIn
  'HackerRank Certificate in Problem Solving'
);

-- Skills
INSERT INTO skills (profile_id, skill_name, proficiency) VALUES
(1, 'C++', 90),
(1, 'Python', 85),
(1, 'JavaScript', 85),
(1, 'React', 80),
(1, 'Node.js', 80),
(1, 'Express.js', 80),
(1, 'MongoDB', 75),
(1, 'Bootstrap', 75),
(1, 'Git/GitHub', 85),
(1, 'VS Code', 90),
(1, 'Jupyter Notebook', 80),
(1, 'LaTeX', 70),
(1, 'Postman', 80),
(1, 'Data Structures & Algorithms', 85),
(1, 'OOP', 85),
(1, 'DBMS', 80),
(1, 'Operating Systems', 75),
(1, 'Computer Networks', 75),
(1, 'Web Development', 85),
(1, 'Machine Learning', 80),
(1, 'Backend Engineering', 80);

-- Projects
INSERT INTO projects (profile_id, title, description, links, skills_text) VALUES
(1, 'Uber Clone Web Application',
   'Developed a full-stack clone of Uber with real-time map integrations and a responsive UI. Implemented features such as ride booking, driver matching, and payment simulation. Used React for frontend and Node.js/Express for backend API handling.',
   '["https://github.com/punith587/UberClone"]', -- replace with actual repo if available
   'React, Node.js, Express, JavaScript, MongoDB'),

(1, 'Alumni Connect: Full-Stack Alumni Association Platform',
   'Designed and developed a full-stack alumni network portal for connecting graduates with current students. Built features like user registration, role-based access, event posting, and mentoring support. Integrated an AI-powered recommendation system to connect alumni with similar interests. Focused on secure authentication, database management, and intuitive interface.',
   '["https://github.com/punith587/AlumniConnect"]', -- replace with actual repo if available
   'React, Node.js, Express, MongoDB, AI'),

(1, 'AI Powered Image Enhancer',
   'Developed a React-based web app to enhance image quality using image processing APIs. Implemented features like background removal, upscaling, and quality improvement. Designed a responsive UI to allow users to upload and instantly preview enhanced results.',
   '["https://github.com/punith587/ImageEnhancer"]', -- replace with actual repo if available
   'React, JavaScript, Image Processing APIs'),

(1, 'IPL Win Probability Predictor',
   'Built a machine learning model to predict IPL team win probability based on match context. Used real-time data (runs, wickets, overs, required run rate). Developed a React frontend for input and dynamic probability display. Leveraged historical IPL data and statistical methods for accuracy.',
   '["https://github.com/punith587/IPLWinPredictor"]', -- replace with actual repo if available
   'Python, Machine Learning, React, Statistics');

-- Work / Experience
INSERT INTO work (profile_id, role, company, start_date, end_date, description) VALUES
(1, 'Machine Learning Intern', 'Mentorness', '2024-01-01', '2024-02-28',
   'Managed end-to-end machine learning pipelines encompassing extensive data preprocessing, advanced feature engineering, and regression model deployment in daily operational workflows, applying predictive modeling strategies to significantly improve model accuracy and enhance overall workflow efficiency in real-world business and technical applications.');
