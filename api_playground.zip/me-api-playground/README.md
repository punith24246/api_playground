# me-api-playground

A full-stack playground project featuring a Node.js/Express backend with SQLite and a simple HTML/CSS/JS frontend. This project demonstrates a basic API for managing user profiles, projects, skills, and work experience.

## Project Structure

```
me-api-playground/
├── backend/
│   ├── database.sqlite      # SQLite database file
│   ├── meapi.db            # (Alternate/legacy) SQLite database file
│   ├── package.json        # Backend dependencies and scripts
│   ├── schema.sql          # SQL schema for database setup
│   ├── seed.sql            # SQL seed data
│   └── src/
│       ├── index.js        # Main Express server
│       ├── db/
│       │   └── database.js # Database connection logic
│       ├── routes/
│       │   ├── profile.js  # Profile API routes
│       │   ├── projects.js # Projects API routes
│       │   ├── search.js   # Search API routes
│       │   ├── skills.js   # Skills API routes
│       │   └── work.js     # Work experience API routes
│       └── utils/
│           └── seed.js     # Database seeding utility
├── frontend/
│   ├── app.js              # Frontend JavaScript
│   ├── index.html          # Main HTML file
│   └── style.css           # Stylesheet
└── docs/
    └── README.md           # Project documentation (this file)
```

## Getting Started

### Prerequisites
- Node.js (v14 or higher recommended)
- npm (comes with Node.js)

### Backend Setup
1. Navigate to the backend folder:
   ```sh
   cd backend
   ```
2. Install dependencies:
   ```sh
   npm install
   ```
3. (Optional) Initialize the database:
   - Run the SQL scripts in `schema.sql` and `seed.sql` using your preferred SQLite tool, or use the provided `utils/seed.js` script if available.

4. Start the backend server:
   ```sh
   npm start
   ```
   The server will typically run on `http://localhost:3000`.

### Frontend Setup
1. Open `frontend/index.html` in your browser.
2. Ensure the backend server is running for API calls to work.

## API Endpoints
- `/profile` - Manage user profile data
- `/projects` - CRUD operations for projects
- `/skills` - Manage user skills
- `/work` - Manage work experience
- `/search` - Search across profiles, projects, etc.

## Development
- Backend code is in `backend/src/`
- Frontend code is in `frontend/`
- Database schema and seed data are in `backend/schema.sql` and `backend/seed.sql`

## License
This project is for educational and demonstration purposes.
